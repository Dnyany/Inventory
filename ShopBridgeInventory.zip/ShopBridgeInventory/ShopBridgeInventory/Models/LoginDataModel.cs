﻿ 
namespace ShopBridgeInventory.Models
{
    public class LoginDataModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Email_ID { get; set; }
    }
}
