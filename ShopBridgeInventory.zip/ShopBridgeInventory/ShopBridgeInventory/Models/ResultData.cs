﻿namespace ShopBridgeInventory.Models
{
    public class ResultData
    {
        public string Result { get; set; }
        public bool Status { get; set; }
        public string ErrorMessage { get; set; }

    }
}
